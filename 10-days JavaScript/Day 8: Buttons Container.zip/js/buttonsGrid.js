window.onload = () => {

    //const btn5 = document.getElementById('btn5');
    
    btn5.addEventListener('click', () => {
        // get all the values from the buttons
        let arr = [
            btn1.textContent,
            btn2.textContent,
            btn3.textContent,
            btn6.textContent,
            btn9.textContent,
            btn8.textContent,
            btn7.textContent,
            btn4.textContent
        ];

        // create new shifted array
        arr = [...arr.slice(arr.length - 1), ...arr.slice(0, arr.length - 1)];

        // assign new values to buttons
        btn1.textContent = arr[0];
        btn2.textContent = arr[1];
        btn3.textContent = arr[2];
        btn6.textContent = arr[3];
        btn9.textContent = arr[4];
        btn8.textContent = arr[5];
        btn7.textContent = arr[6];
        btn4.textContent = arr[7];
    });
};