window.onload = () => {
  //const btn = document.getElementById('btn');

  btn.addEventListener('click', e => {
    e.currentTarget.textContent = parseInt(e.currentTarget.textContent, 0) + 1;
  });
};